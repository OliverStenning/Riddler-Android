package co.roguestudios.riddler.view;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.URLSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.ads.consent.ConsentForm;
import com.google.ads.consent.ConsentFormListener;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;

import java.net.MalformedURLException;
import java.net.URL;

import co.roguestudios.riddler.R;
import co.roguestudios.riddler.classes.PrefManager;
import co.roguestudios.riddler.util.URLSpanNoUnderline;

public class MenuActivity extends AppCompatActivity {

    PrefManager prefManager;

    private ImageButton soundButton;
    private ImageButton musicButton;
    private TextView versionText;

    private ConsentForm form;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_menu);

        prefManager = new PrefManager(this);

        soundButton = findViewById(R.id.soundButton);
        musicButton = findViewById(R.id.musicButton);
        versionText = findViewById(R.id.versionText);

        updateUI();

        //Update version text
        try {
            PackageInfo pInfo = this.getPackageManager().getPackageInfo(getPackageName(), 0);
            versionText.setText("v" + pInfo.versionName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }


        //Switch between custom and default consent
        boolean customConsent = true;
        if(customConsent) {
            //Create consent dialog
            LayoutInflater inflater = LayoutInflater.from(this);
            View consentDialogView = inflater.inflate(R.layout.dialog_consent, null);

            TextView descriptionText = consentDialogView.findViewById(R.id.descriptionText);
            stripUnderlines(descriptionText);
            descriptionText.setMovementMethod(LinkMovementMethod.getInstance());

            AlertDialog consentDialog = new AlertDialog.Builder(this).create();
            consentDialog.setView(consentDialogView);
            consentDialog.getWindow().getAttributes().windowAnimations = R.style.dialogTheme;
            consentDialog.show();
        } else {

        //Manage consent
        ConsentInformation consentInformation = ConsentInformation.getInstance(this);
        String[] publisherIds = {"pub-4605466962808569"};
        consentInformation.requestConsentInfoUpdate(publisherIds, new ConsentInfoUpdateListener() {
            @Override
            public void onConsentInfoUpdated(ConsentStatus consentStatus) {

            }

            @Override
            public void onFailedToUpdateConsentInfo(String reason) {

            }
        });

        URL privacyUrl = null;
        try {
            //TODO replace with our privacy policy
            privacyUrl = new URL("https://www.roguestudios.co");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        ConsentInformation.getInstance(this).addTestDevice("8F85985E1F138565EDB3AD4BFCE7C52D");
        form = new ConsentForm.Builder(this, privacyUrl).withListener(new ConsentFormListener() {
            @Override
            public void onConsentFormLoaded() {
                super.onConsentFormLoaded();
                showConsentForm(form);
            }

            @Override
            public void onConsentFormError(String reason) {
                super.onConsentFormError(reason);
                System.out.println(reason);
            }

            @Override
            public void onConsentFormOpened() {
                super.onConsentFormOpened();
            }

            @Override
            public void onConsentFormClosed(ConsentStatus consentStatus, Boolean userPrefersAdFree) {
                super.onConsentFormClosed(consentStatus, userPrefersAdFree);
                if (consentStatus == ConsentStatus.NON_PERSONALIZED) {
                    prefManager.setConsentPersonalised(false);
                } else {
                    prefManager.setConsentPersonalised(true);
                }
            }
        })
                .withPersonalizedAdsOption()
                .withNonPersonalizedAdsOption()
                .build();
        form.load();
        }

    }

    //Removes underlines from links in textview
    private void stripUnderlines(TextView textView) {
        Spannable s = new SpannableString(textView.getText());
        URLSpan[] spans = s.getSpans(0, s.length(), URLSpan.class);
        for (URLSpan span: spans) {
            int start = s.getSpanStart(span);
            int end = s.getSpanEnd(span);
            s.removeSpan(span);
            span = new URLSpanNoUnderline(span.getURL());
            s.setSpan(span, start, end, 0);
        }
        textView.setText(s);
    }

    private void showConsentForm(ConsentForm form) {
        form.show();
    }

    public void updateUI() {

        //Update sound button image
        if (prefManager.hasSound()) soundButton.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.ic_volume_on_36dp, null));
        else soundButton.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.ic_volume_off_36dp, null));

        //Update music button image
        if (prefManager.hasMusic()) musicButton.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.ic_music_on_36dp, null));
        else musicButton.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.ic_music_off_36dp, null));

    }

    public void clickStart(View view) {

        startActivity(new Intent(this, QuestionActivity.class));

    }

    public void clickLang(View view) {

    }

    public void clickSound(View view) {
        prefManager.setSound(!prefManager.hasSound());
        updateUI();
    }

    public void clickMusic(View view) {
        prefManager.setMusic(!prefManager.hasMusic());
        updateUI();
    }

}
