package co.roguestudios.riddler.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import co.roguestudios.riddler.R;

public class CompletionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_completion);
    }

    public void clickContinue(View view) {

    }

}
